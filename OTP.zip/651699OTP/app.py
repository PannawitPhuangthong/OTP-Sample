from flask import Flask, render_template, request, jsonify
import random
import string
import smtplib
import ssl
import requests
import json
from datetime import datetime, timedelta

app = Flask(__name__)

# ตัวแปรเก็บ OTP ที่สร้างล่าสุด
current_otp = None
otp_expiry_time = None
discord_otp = None
discord_otp_expiry_time = None

# ฟังก์ชันในการสร้าง OTP
def generate_otp():
    characters = string.ascii_letters + string.digits
    return ''.join(random.choices(characters, k=6))

# ฟังก์ชันส่ง OTP ไปยัง Discord Webhook
def send_otp_to_discord(otp):
    discord_webhook_url = "https://discord.com/api/webhooks/1308438375480557628/hQAsz39aNhrezemSI_hUqlSV_REzNOhOYJFY-CUQ-B-H9lUddmPHqEqUJqGSt-eAj_aC"

    message = {
        "content": f"**OTP Verification**\nYour OTP is: {otp}\nThis OTP is valid for 2 minutes. Do not share it with anyone."
    }

    response = requests.post(discord_webhook_url, data=json.dumps(message), headers={"Content-Type": "application/json"})
    if response.status_code == 204:
        return "OTP sent to Discord successfully!"
    else:
        return "Failed to send OTP to Discord"

# ฟังก์ชันส่ง OTP ไปยัง Email
def send_otp_to_email(email, otp):
    port = 465
    smtp_server = "smtp.gmail.com"
    sender_email = "laxmansinghnegi10@gmail.com"
    password = "ztxm bxlv ygfw qmtg"

    message = f"""\
Subject: OTP Verification

Your OTP is: {otp}

This OTP is valid for 2 minutes. Do not share it with anyone.
"""
    context = ssl.create_default_context()
    with smtplib.SMTP_SSL(smtp_server, port, context=context) as server:
        server.login(sender_email, password)
        server.sendmail(sender_email, email, message)

    return "OTP sent to email successfully!"

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/generate_otp', methods=['POST'])
def generate_otp_route():
    global current_otp, otp_expiry_time

    current_otp = generate_otp()
    otp_expiry_time = datetime.now() + timedelta(minutes=2)

    email = request.json.get('email', None)
    email_message = "No email provided."

    if email:
        email_message = send_otp_to_email(email, current_otp)

    return jsonify({
        'otp_expiry_time': otp_expiry_time.isoformat(),
        'email_message': email_message
    })

@app.route('/verify_otp_email', methods=['POST'])
def verify_otp_email():
    global current_otp, otp_expiry_time, discord_otp, discord_otp_expiry_time

    entered_otp = request.form['otp_input']

    # ตรวจสอบ OTP และเวลาหมดอายุ
    if datetime.now() > otp_expiry_time:
        return jsonify({'status': 'error', 'message': 'OTP has expired. Please generate a new one.'})
    elif entered_otp == current_otp:
        discord_otp = generate_otp()
        discord_otp_expiry_time = datetime.now() + timedelta(minutes=2) 
        discord_message = send_otp_to_discord(discord_otp)
        return jsonify({'status': 'success', 'message': 'OTP Verified Successfully. OTP sent to Discord.'})
    else:
        return jsonify({'status': 'error', 'message': 'Invalid OTP. Please try again.'})

@app.route('/verify_otp_discord', methods=['POST'])
def verify_otp_discord():
    global discord_otp

    entered_otp = request.form['otp_input']

    # ตรวจสอบ OTP และเวลาหมดอายุของ Discord OTP
    if datetime.now() > discord_otp_expiry_time:
        return jsonify({'status': 'error', 'message': 'Discord OTP has expired. Please generate a new one.'})
    elif entered_otp == discord_otp:
        return jsonify({'status': 'success', 'message': 'Discord OTP Verified Successfully!'})
    else:
        return jsonify({'status': 'error', 'message': 'Invalid OTP. Please try again.'})

if __name__ == '__main__':
    app.run(debug=True)